<footer class="bg-red px-8 py-4 justify-end">
    <div class="container">
        <p class="text-center text-cream font-bold text-lg">Copyright Nadine Annisa Heartman. All Rights Reserved</p>
    </div>
</footer>
