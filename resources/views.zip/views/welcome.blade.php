@extends('components.layout')

@section('content')
    <main class="py-14 mb-8">

    </main>
@endsection
